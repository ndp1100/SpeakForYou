var searchData=
[
  ['wait_5ftime',['WAIT_TIME',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1social_1_1_social_service.html#a19fcd6e2c108ac3e0e1559c537ac9880',1,'com::shephertz::app42::paas::sdk::csharp::social::SocialService']]],
  ['width',['width',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image.html#abd9f21f84254ff9726ad6ae63d964978',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor::Image']]],
  ['within',['WITHIN',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1storage_1_1_geo_operator.html#ad96cee4068fce0e677b8151f01bb128e',1,'com::shephertz::app42::paas::sdk::csharp::storage::GeoOperator']]],
  ['wp7',['WP7',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1push_notification_1_1_device_type.html#a076d1c4987340289ec7113e2b144fa3d',1,'com::shephertz::app42::paas::sdk::csharp::pushNotification::DeviceType']]],
  ['write',['WRITE',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_permission.html#a3bab9f6bd2bf5bd2ae808d0309c5fc12',1,'com::shephertz::app42::paas::sdk::csharp::Permission']]]
];
