var searchData=
[
  ['x',['x',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image.html#a105625bbf12f1fda2e9a948b6e9bbb0c',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor::Image']]],
  ['xml',['XML',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1upload_1_1_upload_file_type.html#a7ea524186404c20daf27dc9f4ce9c507',1,'com::shephertz::app42::paas::sdk::csharp::upload::UploadFileType']]],
  ['xmpp_5flogin',['xmpp_login',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1social_1_1_f_b_perms.html#a3b784e05553a8572bbf657ce781ee4e0',1,'com::shephertz::app42::paas::sdk::csharp::social::FBPerms']]]
];
