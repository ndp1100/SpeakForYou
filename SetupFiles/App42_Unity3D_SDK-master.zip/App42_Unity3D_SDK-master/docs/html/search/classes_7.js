var searchData=
[
  ['image',['Image',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image.html',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor']]],
  ['imageprocessorservice',['ImageProcessorService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image_processor_service.html',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor']]],
  ['item',['Item',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1shopping_1_1_cart_1_1_item.html',1,'com::shephertz::app42::paas::sdk::csharp::shopping::Cart']]],
  ['item',['Item',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1shopping_1_1_catalogue_1_1_category_1_1_item.html',1,'com::shephertz::app42::paas::sdk::csharp::shopping::Catalogue::Category']]],
  ['itemdata',['ItemData',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1shopping_1_1_item_data.html',1,'com::shephertz::app42::paas::sdk::csharp::shopping']]]
];
