var searchData=
[
  ['onexception',['OnException',['../interfacecom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_app42_call_back.html#aae9de304ea92ea277d72431a60f7bfb6',1,'com.shephertz.app42.paas.sdk.csharp.App42CallBack.OnException()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1social_1_1_facebook_service.html#ae2f0254ca00dfff980ff8302079e4d6b',1,'com.shephertz.app42.paas.sdk.csharp.social.FacebookService.OnException()']]],
  ['onsuccess',['OnSuccess',['../interfacecom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_app42_call_back.html#a677094e4162da840ad9278ad340f968d',1,'com.shephertz.app42.paas.sdk.csharp.App42CallBack.OnSuccess()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1social_1_1_facebook_service.html#a59e67303684474110bbd7ab222668778',1,'com.shephertz.app42.paas.sdk.csharp.social.FacebookService.OnSuccess()']]]
];
