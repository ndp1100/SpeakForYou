var searchData=
[
  ['buddy',['Buddy',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1buddy_1_1_buddy.html',1,'com::shephertz::app42::paas::sdk::csharp::buddy']]],
  ['buddyservice',['BuddyService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1buddy_1_1_buddy_service.html',1,'com::shephertz::app42::paas::sdk::csharp::buddy']]]
];
