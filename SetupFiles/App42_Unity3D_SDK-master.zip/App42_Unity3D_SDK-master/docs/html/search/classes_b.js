var searchData=
[
  ['operator',['Operator',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1storage_1_1_operator.html',1,'com::shephertz::app42::paas::sdk::csharp::storage']]],
  ['orderbytype',['OrderByType',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1storage_1_1_order_by_type.html',1,'com::shephertz::app42::paas::sdk::csharp::storage']]]
];
