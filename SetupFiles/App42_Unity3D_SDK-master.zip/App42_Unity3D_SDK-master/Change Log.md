* [Release Version 4.1.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-412)
* [Release Version 3.4](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-34)
* [Release Version 4.1.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-411)
* [Release Version 4.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-41)
* [Release Version 4.0.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-401)
* [Release Version 4.0](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-40)
* [Release Version 4.0 Beta](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-40-beta)
* [Release Version 3.3.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-331)
* [Release Version 3.3](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-33)
* [Release Version 3.2.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-322)
* [Release Version 3.2.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-321)
* [Release Version 3.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-32)
* [Release Version 3.1.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-312)
* [Release Version 3.1.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-311)
* [Release Version 3.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-31)
* [Release Version 3.0.3](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-303)
* [Release Version 3.0.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-302)
* [Release Version 3.0.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-301)
* [Release Version 3.0](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-30)
* [Release Version 2.9.4](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-294)
* [Release Version 2.9.3](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-293)
* [Release Version 2.9.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-292)
* [Release Version 2.9.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-291)
* [Release Version 2.9](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-29)
* [Release Version 2.8](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-28)
* [Release Version 2.7.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-272)
* [Release Version 2.7.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-271)
* [Release Version 2.7](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-27)
* [Release Version 2.6.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-261)
* [Release Version 2.6](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-26)
* [Release Version 2.5.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-251)
* [Release Version 2.5](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-25)
* [Release Version 2.4.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-241)
* [Release Version 2.4](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-24)
* [Release Version 2.3.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-231)
* [Release Version 2.3](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-23)
* [Release Version 2.2.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-222)
* [Release Version 2.2.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-221)
* [Release Version 2.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-22)
* [Release Version 2.1.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-211)
* [Release Version 2.1](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-21)
* [Release Version 2.0.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-202)
* [Release Version 2.0](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-20)
* [Release Version 1.9](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-19)
* [Release Version 1.8](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-18)
* [Release Version 1.7.2](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-172)
* [Release Version 1.7](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-17)
* [Release Version 1.6](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-16)
* [Release Version 1.5](https://github.com/shephertz/App42_Unity3D_SDK/blob/master/Change%20Log.md#version-15)

## Version 4.1.2

**Release Date:** 12-08-2015

**Release Version:** 4.1.2

**This release contains the following bug fix:**
```
1. Offline response type changed to App42OfflineResponse.
```

## Version 3.4

**Release Date:** 04-08-2015

**Release Version:** 3.4

**This release contains the following enhancements :**
```
Supports on Unity version 4.6.x.
```

## Version 4.1.1

**Release Date:** 13-07-2015

**Release Version:** 4.1.1

**This release contains the following bug fix:**
```
1. CreateUserWithProfile default dateOFBirth set to null.
```

## Version 4.1

**Release Date:** 09-07-2015

**Release Version:** 4.1

**The following features have been pushed to the services :**

**ACHIEVEMENT SERVICE**
```
1. DeleteUserAchievement.
```

**PUSH NOTIFICATION SERVICE**
```
1. TrackPush.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 4.0.1

**Release Date:** 15-06-2015

**Release Version:** 4.0.1

**This release contains the following enhancements :**
```
Build for universal apps on Windows Store platform.
```

## Version 4.0

**Release Date:** 15-05-2015

**Release Version:** 4.0

**Platforms which are supported in this release:**

```
Unity Web Player
Android
iOS (Mono) & iOS (IL2CPP)
Desktop Standalone app
Windows Phone
WebGL
Windows Store
```

## Version 4.0 Beta

**Release Date:** 03-04-2015

**Release Version:** 4.0

**Platforms which are supported in this release:**

```
Unity Web Player
Android
iOS (Mono) & iOS (IL2CPP)
Desktop Standalone app
Window Phone
```

**Platforms which are not supported in this release:**

```
Unity Web Player for Firefox and Safari.
Window Store Apps.
WebGL
```
Note: If you have any query, please feel free to reach us at support@shephertz.com or report your bug [here](https://github.com/shephertz/App42_Unity3D_SDK/issues).

## Version 3.3.1

**Release Date:** 20-04-2015

**Release Version:** 3.3.1

**This release contains the following bug fix:**
```
1. Push message in JSON string fixed.
```

## Version 3.3

**Release Date:** 10-04-2015

**Release Version:** 3.3

**The following features have been pushed to the services :**

**STORAGE SERVICE**
```
1. IncrementKeyByDocId.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 3.2.2

**Release Date:** 02-04-2015

**Release Version:** 3.2.2

**This release contains the following bug fix:**
```
1. DoFBOAuthAndGetToken Bug Fix.
```

## Version 3.2.1

**Release Date:** 10-03-2015

**Release Version:** 3.2.1

**This release contains the following bug fix:**
```
1. Handle exception on large body.
```

## Version 3.2

**Release Date:** 10-02-2015

**Release Version:** 3.2

**This release contains the following new feature :**
```
Offline Storage Support.
```

**This release contains the following bug fix:**
```
1. CreateOrUpdateUserProfile bug fix.
```

## Version 3.1.2

**Release Date:** 16-01-2014

**Release Version:** 3.1.2

**The following features have been pushed to the services :**

**PushNotification SERVICE**
```
1. SendPushTileMessageToUser.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 3.1.1

**Release Date:** 06-01-2014

**Release Version:** 3.1.1

**This release contains the following modification:**

```
1. App42API.SetCustomCodeURL method added.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 3.1

**Release Date:** 15-12-2014

**Release Version:** 3.1

**The following features have been pushed to the services :**

**ABTest SERVICE**
```
1. GetVariantData.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 3.0.3

**Release Date:** 05-12-2014

**Release Version:** 3.0.3

**This release contains the following bug fix:**
```
1. JSON bug Fix For WP8.
```

## Version 3.0.2

**Release Date:** 21-11-2014

**Release Version:** 3.0.2

**This release contains the following bug fix:**
```
1. JSON bug Fix.
```

## Version 3.0.1

**Release Date:** 16-11-2014

**Release Version:** 3.0.1

**This release contains the following bug fix:**
```
1. InvalidCastException In Upload bug fix.
```

## Version 3.0

**Release Date:** 27-10-2014

**Release Version:** 3.0


**The following Services have been pushed to the latest :**
```
1. Event Service.
```

**This release contains the following bug fix:**
```
1. None.
```

## Version 2.9.4

**Release Date:** 10-10-2014

**Release Version:** 2.9.4


**The following Services have been pushed to the latest :**
```
1. BravoBoard Service.
```

**The following features have been pushed to the services :**

**BUDDY SERVICE**
```
1. DeleteAllMessages.
2. GetBlockedBuddyList.
```

**PUSH NOTIFICATION SERVICE**
```
1. GetAllDevicesOfUser.
2. SendPushMessageToAppGroup.
```

**QUERY BUILDER**
```
1. SetCreatedOn
2. SetUpdatedOn
3. SetDocumentId
```

**This release contains the following bug fix:**

```
1. User SessionId and fbAccessToken Conflict.
```

## Version 2.9.3

**Release Date:** 15-09-2014

**Release Version:** 2.9.3

**This release contains the following bug fix:**

```
1. Duplicate Keys in Dictionary in SessionService.
```

## Version 2.9.2

**Release Date:** 01-09-2014

**Release Version:** 2.9.2

**This release contains the following modification:**

```
1. Overloaded method for SetBaseUrl added.
```

## Version 2.9.1

**Release Date:** 28-07-2014

**Release Version:** 2.9.1

**This release contains the following bug fix:**

```
1. Simple JSON Bug Fix.
2. Blank value is allowed in Dictionary in storage service.
```


## Version 2.9

**Release Date:** 21-06-2014

**Release Version:** 2.9


**The following Services have been pushed to the latest :**
```
1. Timer Service.
2. Gift Service.
```
**This release contains the following bug fix:**

```
None
```

## Version 2.8

**Release Date:** 09-06-2014

**Release Version:** 2.8


**The following features have been pushed to the services :**

**AVATAR SERVICE**
```
1. DeleteAllAvatars.
2. DeleteAvatarByName.
3. UpdateAvatar.
```

**This release contains the following bug fix:**

```
None.
```

## Version 2.7.2

**Release Date:** 24-05-2014

**Release Version:** 2.7.2

**This release contains the following bug fix:**

```
FindDocsWithQueryPagingOrderBy bug fixed in WP8.
```

## Version 2.7.1

**Release Date:** 23-05-2014

**Release Version:** 2.7.1

**This release contains the following bug fix:**

```
InvalidClassCastException issue solved in WP8.
```


## Version 2.7

**Release Date:** 13-05-2014

**Release Version:** 2.7


**The following features have been changed :**

```
If you are upgrading from previous version of App42_Unity3D_SDK and have used GetRecordCount() method on storage service, you have to change its return type as long instead of string, because the return type of this method is changed.

**OlD Code Snippet:
string recordCount = storageResponse.GetRecordCount();

**New Code Snippet :
long recordCount = storageResponse.GetRecordCount();
```

**The following features have been pushed to the services :**

**PUSH NOTIFICATION SERVICE**
```
1. DeleteAllDevices.
2. SendPushMessageToDevice.
3. UpdatePushBadgeforDevice.
4. UpdatePushBadgeforUser.
```

**STORAGE SERVICE**
```
1. GetCountByQuery.
```

**This release contains the following bug fix:**

```
None.
```

## Version 2.6.1

**Release Date:** 25-04-2014

**Release Version:** 2.6.1


**The following features have been pushed to the services :**

**SOCIAL SERVICE**
```
1. DoFBOAuthAndGetToken Is Now Available in Unity_WP8.
```

**This release contains the following bug fix:**

```
1. CallBack Threading issue for Unity_WP8 Fixed. 
```


## Version 2.6

**Release Date:** 14-04-2014

**Release Version:** 2.6


**The following features have been pushed to the services :**

**SOCIAL SERVICE**
```
1. DoFBOAuthAndGetToken.  // Not Available in Unity_WP8.
```

**New feature Added :**
```
1. LoggedIn User SessionId And UserName in Local Session.
```

**This release contains the following bug fix:**

```
1. No Network Bug Fix For Unity_WP8.
2. Debug.Log Removed.
3. Exception Message Changed For Unity_WP8.
```


## Version 2.5.1

**Release Date:** 09-04-2014

**Release Version:** 2.5.1


**This release contains the following bug fix:**

```
Map Reduce Bug Fix.
```

## Version 2.5

**Release Date:** 04-04-2014

**Release Version:** 2.5


**The following features have been pushed to the services :**

**SCOREBOARD SERVICE**
```
1.GetUsersWithScoreRange.
```

**This release contains the following bug fix:**

```
None.
```

## Version 2.4.1

**Release Date:** 27-03-2014

**Release Version:** 2.4.1

**This release contains the following bug fix:**

```
1. System.SystemException for Windows Store Apps bug fix.
```


## Version 2.4

**Release Date:** 26-03-2014

**Release Version:** 2.4

**The following features have been changed :**

```
If you are upgrading from previous version of App42_Unity3D_SDK and have used SetQuery method on any service, you have to set App42API.SetDbName instead of passing it in method parameter.

**OlD Code Snippet:
SetQuery("dbName","collectionName","query");

**New Code Snippet :
App42API.SetDbName("dbName");
SetQuery("collectionName","query");
```

**The following features have been pushed to the services :**

**STORAGE SERVICE**

```
1.AddOrUpdateKeys.
2.AddAttachmentToDocs.
3.InsertJSONDocument(With Attached File).
```

**User SERVICE**

```
1.AddJSONObject(Add Extra Information while creating user).
2.CreateUserWithProfile.
3.GetUsersByGroup.
```

**PUSH NOTIFICATION SERVICE**
```
1.UnSubscribeDevice.
2.ReSubscribeDevice.
```

**SCOREBOARD SERVICE**
```
1.AddJSONObject(Add Extra Information of user while saving score).
```

**This release contains the following bug fix:**

```
None.
```


## Version 2.3.1

**Release Date:** 01-03-2014

**Release Version:** 2.3.1

**This release contains the following bug fix:**

```
1. Network On and Off during gameplay bug fix.
```

## Version 2.3

**Release Date:** 27-02-2014

**Release Version:** 2.3

**The following features have been pushed  :**

```
Handle crash Event.
```

**The following features have been pushed to the services :**

**REVIEW SERVICE**
```
1.GetAllReviewsByUser.
```

**This release contains the following bug fix:**

```
OrderByType Bug Fix.
```

## Version 2.2.2

**Release Date:** 17-02-2014

**Release Version:** 2.2.2

**This release contains the following bug fix:**

```
1. Installation Id bug fix for WP8.
```

## Version 2.2.1

**Release Date:** 11-02-2014

**Release Version:** 2.2.1

**This release contains the following bug fix:**

```
1. Installation Id bug fix.
```

## Version 2.2

**Release Date:** 06-02-2014

**Release Version:** 2.2

**The following features have been pushed  :**

```
MetaInfo in UserService (GetUser, GetUsersByRole, GetUserByEmailId) and ScoreBoardService(GetTopNRankers, GetTopNTargetRankers).
```

**The following features have been pushed to the services :**

**STORAGE SERVICE**
```
1.Inlist Support for storage query.
2.SaveOrUpdateDocumentByKeyValue.
3.UpdateDocumentByQuery.
```

**PHOTO SERVICE**
```
1.UpdatePhoto.
```

**PUSH NOTIFICATION SERVICE**
```
1.SendMessageToInActiveUsers.
2.ScheduleMessageToUser.
```

**REVIEW SERVICE**
```
1.DeleteReviewByReviewId.
2.DeleteCommentByCommentId.
```

**SCOREBOARD SERVICE**
```
1.GetTopNTargetRankers.
2.GetTopNRankersFromFacebook(including rankers in specified date range).
```

**BUDDY SERVICE**
```
1.Unfriend.
2.DeleteMessageById.
3.DeleteMessageByIds.
```

**This release contains the following bug fix:**

```
None.
```

## Version 2.1.1

**Release Date:** 29-1-2014

**Release Version:** 2.1.1

**This release contains the following bug fix:**

```
1. Get Total Records BugFix.
```

## Version 2.1

**Release Date:** 14-1-2014

**Release Version:** 2.1

**The following features have been pushed to the services :**

**PUSH NOTIFICATION SERVICE**

```
1.Schedule Message To User
```

**This release contains the following bug fix:**

```
None
```

## Version 2.0.2

**Release Date:** 3-1-2014

**Release Version:** 2.0.2

**The following features have been added to the SDK :**

```
None
```

**This release contains the following bug fix:**

```
Unhandle Network Exception
```

## Version 2.0

**Release Date:** 13-12-2013

**Release Version:** 2.0

**The following features have been added to the SDK :**
```
* __Windows Phone 8 Support__
```

**This release contains the following bug fix:**

```
None
```
## Version 1.9

**Release Date:** 31-10-2013

**Release Version:** 1.9

**The following Services have been pushed to the latest :**

```
AB Testing Service
```

**The following features have been pushed to the services :**

**SCOREBOARD SERVICE**

```
GetTopNRankersFromFacebook
```

**This release contains the following bug fix:**

```
None
```


## Version 1.8

**Release Date:** 18-10-2013

**Release Version:** 1.8

**The following Services have been pushed to the latest :**

```
Avatar Service
Upload Service
ImageProcessor Service
Gallery Service
ShoppingCart/Catalogue Service
Geo Service
Message Service
```

**This release contains the following bug fix:**

```
Response bug fixed.
```

## Version 1.7.2

**Release Date:** 18-10-2013

**Release Version:** 1.7.2

**The following Services have been pushed to the latest :**

```
None
```

**This release contains the following bug fix:**

```
Response bug fixed.
```

## Version 1.7

**Release Date:** 23-09-2013

**Release Version:** 1.7

**The following Services have been pushed to the latest :**

```
Achievement Service
```

**The following features have been pushed to the services :**

**SOCIAL SERVICE**

```
facebookPublishStream
facebookLinkPost
facebookLinkPostWithCustomThumbnail
getFacebookProfile
```

**PUSHNOTIFICATION SERVICE**

```
sendPushMessageToGroup
deleteDeviceToken
```


**This release contains the following bug fix:**

```
None
```

## Version 1.6

**Release Date:** 05-09-2013

**Release Version:** 1.6

**The following feature have been pushed to the latest :**

```
Cross platform support Web player, iOS , Android.
```

**This release contains the following bug fix:**

**CustomCode Service**

```
RunJavaCode
```

**Storage Service**

```
UpdateDocumentByKeyValue
UpdateDocumentByDocId
```

Note : - **Release 1.6** does not contain the following services in Asnc mode:- 

```
Cart/Catalogue Service
Recommender Service
Upload Service
Gallery Service
ImageProcessor Service
Message/Queue Service
Geo Service
```

## Version 1.5

**Release Date:** 05-08-2013

**Release Version:** 1.5

**The following feature have been pushed to the latest :**


**SCOREBOARD SERVICE**

```
GetTopNRankers 
GetTopNRankers (Between Date)
EditScoreValueById 
GetTopRankersFromBuddyGroup
```


**STORAGE SERVICE**

```
DeleteAllDocuments
FindDocumentsByLocation
DeleteDocumentsByKeyValue
```


**USER SERVICE**

```
LogOut
```


**PUSHNOTIFICATION SERVICE**

```
UnsubscribeDeviceToChannel
SubscribeToChannel
```


**UPLOAD SERVICE**

```
UploadFileForFriend
UploadFileForFriendS
UploadFileForGroup
```


**BUDDY SERVICE**

```
SendMessageToGroup
SendMessageToFriend
SendMessageToFriends
GetAllMessages
GetAllMessagesFromBuddy
GetAllMessagesFromGroup
```


**This release contains the following bug fix:**

```
ios build
```
